# LUCID vs Softmax Attention Sink Experiment

## Overview

This experiment demonstrates that LUCID attention can break out of "attention sinks" formed during earlier training, while standard Softmax attention gets permanently stuck in self-attention patterns.

## Experiment Design

**Two-phase training:**
- **Phase 1 (Identity Task):** Train to output the input token value at each position. This forces the model to learn pure self-attention (attend only to itself).
- **Phase 2 (Cumulative Average Task):** Train to output the running average of all tokens seen so far. This requires uniform attention over all previous positions.

**Key insight:** Phase 1 creates an "attention sink" where the model learns 100% self-attention. In Phase 2, the model must break out of this pattern to learn cumulative averaging.

## Configuration

| Parameter | Value |
|-----------|-------|
| d_model | 256 |
| seq_len | 10 |
| vocab_size | 10 |
| batch_size | 64 |
| learning_rate | 1e-3 |
| scheduler | Cosine annealing with 5% linear warmup |
| Phase 1 steps | 30,000 |
| Phase 2 steps | 10,000 |
| Data generation | Unique tokens (permutations of 0-9) |

## Results

### Attention Pattern After Phase 1

| Metric | Value |
|--------|-------|
| Diagonal (self-attention) | **0.9998** |
| Off-diagonal | 0.000051 |

The identity task successfully creates a near-perfect attention sink (99.98% self-attention).

### Phase 2 Final Loss

| Model | Final Loss | Min Loss | vs Baseline |
|-------|------------|----------|-------------|
| **Softmax** | **1.339** | 0.859 | Barely beats baseline - **STUCK** |
| **LUCID** | **0.126** | 0.079 | 93% better - **RECOVERING** |
| Baseline (predict mean) | 1.83 | - | - |

### Key Finding

- **Softmax is stuck:** After learning the attention sink in Phase 1, Softmax can barely improve beyond the baseline in Phase 2. It only achieves ~27% improvement over predicting the mean.
- **LUCID recovers:** Despite the same Phase 1 training, LUCID achieves 93% improvement over baseline, with ~10x lower loss than Softmax.

## Quick Start

### Installation

```bash
pip install -r requirements.txt
```

### Run Experiment

```bash
python exp_attention_sink.py
```

Results are saved to: `exp_d256_seq10_unique_cosine.npz`

### Load Results

```python
import numpy as np
data = np.load('exp_d256_seq10_unique_cosine.npz')
# Keys: softmax_p1, softmax_p2, lucid_p1, lucid_p2
# Each array contains per-step loss values

print(f"Softmax Phase 2 final loss: {data['softmax_p2'][-1]:.6f}")
print(f"LUCID Phase 2 final loss: {data['lucid_p2'][-1]:.6f}")
```

| Key | Shape | Description |
|-----|-------|-------------|
| softmax_p1 | (30000,) | Softmax Phase 1 losses |
| softmax_p2 | (10000,) | Softmax Phase 2 losses |
| lucid_p1 | (30000,) | LUCID Phase 1 losses |
| lucid_p2 | (10000,) | LUCID Phase 2 losses |

## Why Unique Tokens Matter

With `seq_len=10` and `vocab_size=10`, using unique tokens (permutations) ensures:
- Each token appears exactly once per sequence
- The model **must** learn pure self-attention to solve the identity task
- No "shortcut" by attending to other positions with the same token value

With random tokens (repeats allowed), the model can achieve ~80% diagonal attention but not 100%, which makes it easier to escape the attention sink in Phase 2.

## Model Architectures

### Standard Softmax Transformer
- Token embedding → Q/K/V projections → Softmax attention → Output head
- Standard scaled dot-product attention with causal mask

### LUCID Transformer
- Token embedding → Q/K/V projections → **RMSNorm on K** → **Triangular solve on V** → Softmax attention → Output head
- The triangular solve modifies the value vectors based on key similarities, enabling better gradient flow

## Command to Reproduce

You can also run the experiment directly with this inline command:

```bash
python -u -c "
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import random
import numpy as np
import math

def generate_unique_batch(batch_size, seq_len=10, vocab_size=10, device='cpu'):
    batch = torch.zeros(batch_size, seq_len, dtype=torch.long, device=device)
    for i in range(batch_size):
        perm = torch.randperm(vocab_size)[:seq_len]
        batch[i] = perm
    return batch

def cumulative_average(x):
    cumsum = torch.cumsum(x.float(), dim=1)
    positions = torch.arange(1, x.shape[1] + 1, device=x.device).float()
    return cumsum / positions

def get_cosine_schedule_with_warmup(optimizer, num_warmup_steps, num_training_steps):
    def lr_lambda(current_step):
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1, num_warmup_steps))
        progress = float(current_step - num_warmup_steps) / float(max(1, num_training_steps - num_warmup_steps))
        return max(0.0, 0.5 * (1.0 + math.cos(math.pi * progress)))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

def init_weights(module, d_model=256):
    if isinstance(module, nn.Embedding):
        nn.init.normal_(module.weight, mean=0.0, std=0.02)
    elif isinstance(module, nn.Linear):
        nn.init.xavier_uniform_(module.weight)
        if module.bias is not None:
            nn.init.zeros_(module.bias)

class HypothesisTransformer(nn.Module):
    def __init__(self, d_model=256, seq_len=10):
        super().__init__()
        self.d_model = d_model
        self.d_head = d_model
        self.token_embedding = nn.Embedding(10, d_model)
        self.q_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_proj = nn.Linear(d_model, d_model, bias=False)
        self.v_proj = nn.Linear(d_model, d_model, bias=False)
        self.output_head = nn.Linear(d_model, 1)
        self.last_attn = None

    def forward(self, x):
        B, L = x.shape
        device = x.device
        h = self.token_embedding(x)
        q = self.q_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        k = self.k_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        v = self.v_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.d_head)
        mask = torch.triu(torch.ones((L, L), device=device), diagonal=1).bool()
        scores = scores.masked_fill(mask, float('-inf'))
        attn_probs = F.softmax(scores, dim=-1)
        self.last_attn = attn_probs.detach()
        context = torch.matmul(attn_probs, v)
        h = context.transpose(1, 2).contiguous().view(B, L, self.d_model)
        return self.output_head(h).squeeze(-1)

class HypothesisLucidTransformer(nn.Module):
    def __init__(self, d_model=256, seq_len=10):
        super().__init__()
        self.d_model = d_model
        self.d_head = d_model
        self.token_embedding = nn.Embedding(10, d_model)
        self.q_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_proj = nn.Linear(d_model, d_model, bias=False)
        self.v_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_rms = nn.RMSNorm(self.d_head)
        self.output_head = nn.Linear(d_model, 1)

    def forward(self, x):
        B, L = x.shape
        device = x.device
        h = self.token_embedding(x)
        q = self.q_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        k = self.k_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        v = self.v_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        k_rms = self.k_rms(k)
        kkt = torch.matmul(k_rms, k_rms.transpose(-2, -1)) / math.sqrt(self.d_head) - math.sqrt(self.d_head)
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.d_head)
        mask = torch.triu(torch.ones((L, L), device=device), diagonal=1).bool()
        kkt = kkt.masked_fill(mask, -float('inf'))
        scores = scores.masked_fill(mask, -float('inf'))
        kkt = torch.exp(kkt)
        v = torch.linalg.solve_triangular(kkt, v, upper=False, unitriangular=True)
        attn_probs = F.softmax(scores, dim=-1)
        context = torch.matmul(attn_probs, v)
        h = context.transpose(1, 2).contiguous().view(B, L, self.d_model)
        return self.output_head(h).squeeze(-1)

# Config
d_model, seq_len, vocab_size, batch_size = 256, 10, 10, 64
lr = 1e-3
p1_steps = 30000
p2_steps = 10000
total_steps = p1_steps + p2_steps
warmup_steps = int(0.05 * total_steps)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

print('=== Experiment: d_model=256, seq_len=10, UNIQUE tokens ===')
print(f'lr={lr}, cosine annealing with {warmup_steps} warmup steps (5%)')
print(f'Phase 1: {p1_steps} steps (identity)')
print(f'Phase 2: {p2_steps} steps (cumulative average)')
print(f'Device: {device}')
print()

results = {}

for name, ModelClass in [('Softmax', HypothesisTransformer), ('LUCID', HypothesisLucidTransformer)]:
    print(f'=== Training {name} ===')

    seed = 42
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    model = ModelClass(d_model=d_model, seq_len=seq_len).to(device)
    model.apply(lambda m: init_weights(m, d_model))
    optimizer = optim.Adam(model.parameters(), lr=lr)
    scheduler = get_cosine_schedule_with_warmup(optimizer, warmup_steps, total_steps)

    p1_losses = []
    p2_losses = []

    # Phase 1: Identity
    print('Phase 1 (Identity)...')
    for step in range(p1_steps):
        model.train()
        optimizer.zero_grad()
        inputs = generate_unique_batch(batch_size, seq_len=seq_len, vocab_size=vocab_size, device=device)
        targets = inputs.float()
        loss = F.mse_loss(model(inputs), targets)
        loss.backward()
        optimizer.step()
        scheduler.step()
        p1_losses.append(loss.item())
        if step % 10000 == 0 or step == p1_steps - 1:
            print(f'  Step {step+1}/{p1_steps} | Loss: {loss.item():.6f} | LR: {scheduler.get_last_lr()[0]:.6f}')

    # Check attention after Phase 1 (for Softmax only)
    if name == 'Softmax':
        model.eval()
        with torch.no_grad():
            test_input = generate_unique_batch(1, seq_len=seq_len, vocab_size=vocab_size, device=device)
            _ = model(test_input)
            attn = model.last_attn.squeeze()
            diag = attn.diag().mean().item()
            offdiag_mask = torch.tril(torch.ones(seq_len, seq_len, device=device), diagonal=-1).bool()
            offdiag = attn[offdiag_mask].mean().item()
            print(f'  After Phase 1 - Attn diag: {diag:.4f}, offdiag: {offdiag:.6f}')

    # Phase 2: Cumulative Average
    print('Phase 2 (Cumulative Average)...')
    for step in range(p2_steps):
        model.train()
        optimizer.zero_grad()
        inputs = generate_unique_batch(batch_size, seq_len=seq_len, vocab_size=vocab_size, device=device)
        targets = cumulative_average(inputs)
        loss = F.mse_loss(model(inputs), targets)
        loss.backward()
        optimizer.step()
        scheduler.step()
        p2_losses.append(loss.item())
        if step % 2000 == 0 or step == p2_steps - 1:
            print(f'  Step {step+1}/{p2_steps} | Loss: {loss.item():.6f} | LR: {scheduler.get_last_lr()[0]:.6f}')

    results[name] = {'p1_losses': p1_losses, 'p2_losses': p2_losses}
    print()

# Save results
np.savez('exp_d256_seq10_unique_cosine.npz',
         softmax_p1=np.array(results['Softmax']['p1_losses']),
         softmax_p2=np.array(results['Softmax']['p2_losses']),
         lucid_p1=np.array(results['LUCID']['p1_losses']),
         lucid_p2=np.array(results['LUCID']['p2_losses']))
print('Saved: exp_d256_seq10_unique_cosine.npz')

print()
print('=' * 60)
print('RESULTS')
print('=' * 60)
print(f'Phase 2 Final Loss:')
print(f'  Softmax: {results[\"Softmax\"][\"p2_losses\"][-1]:.6f}')
print(f'  LUCID:   {results[\"LUCID\"][\"p2_losses\"][-1]:.6f}')
print()
print('Baseline (predict mean): ~1.83')
"
```

## File Structure

```
.
├── README.md                        # This file
├── requirements.txt                 # Python dependencies
├── exp_attention_sink.py            # Main experiment script
└── exp_d256_seq10_unique_cosine.npz # Results (generated after running)
```
