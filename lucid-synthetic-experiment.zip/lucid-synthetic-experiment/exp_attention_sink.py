"""
LUCID vs Softmax Attention Sink Experiment

This script demonstrates that LUCID attention can break out of "attention sinks"
formed during earlier training, while standard Softmax attention gets permanently
stuck in self-attention patterns.

Two-phase training:
- Phase 1 (Identity Task): Train to output the input token value at each position.
  This forces the model to learn pure self-attention (attend only to itself).
- Phase 2 (Cumulative Average Task): Train to output the running average of all
  tokens seen so far. This requires uniform attention over all previous positions.

Usage:
    python exp_attention_sink.py

Results are saved to: exp_d256_seq10_unique_cosine.npz
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import random
import numpy as np
import math


def generate_unique_batch(batch_size, seq_len=10, vocab_size=10, device='cpu'):
    """Generate batch where each sequence has unique tokens (permutations).

    This ensures the model must learn pure self-attention to solve the identity task,
    with no shortcut by attending to other positions with the same token value.
    """
    batch = torch.zeros(batch_size, seq_len, dtype=torch.long, device=device)
    for i in range(batch_size):
        perm = torch.randperm(vocab_size)[:seq_len]
        batch[i] = perm
    return batch


def cumulative_average(x):
    """Compute cumulative average: output[i] = mean(input[0:i+1])"""
    cumsum = torch.cumsum(x.float(), dim=1)
    positions = torch.arange(1, x.shape[1] + 1, device=x.device).float()
    return cumsum / positions


def get_cosine_schedule_with_warmup(optimizer, num_warmup_steps, num_training_steps):
    """Cosine annealing learning rate schedule with linear warmup."""
    def lr_lambda(current_step):
        if current_step < num_warmup_steps:
            return float(current_step) / float(max(1, num_warmup_steps))
        progress = float(current_step - num_warmup_steps) / float(max(1, num_training_steps - num_warmup_steps))
        return max(0.0, 0.5 * (1.0 + math.cos(math.pi * progress)))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def init_weights(module, d_model=256):
    """Standard transformer initialization."""
    if isinstance(module, nn.Embedding):
        nn.init.normal_(module.weight, mean=0.0, std=0.02)
    elif isinstance(module, nn.Linear):
        nn.init.xavier_uniform_(module.weight)
        if module.bias is not None:
            nn.init.zeros_(module.bias)


class HypothesisTransformer(nn.Module):
    """Standard Softmax Attention Transformer."""

    def __init__(self, d_model=256, seq_len=10):
        super().__init__()
        self.d_model = d_model
        self.d_head = d_model
        self.token_embedding = nn.Embedding(10, d_model)
        self.q_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_proj = nn.Linear(d_model, d_model, bias=False)
        self.v_proj = nn.Linear(d_model, d_model, bias=False)
        self.output_head = nn.Linear(d_model, 1)
        self.last_attn = None

    def forward(self, x):
        B, L = x.shape
        device = x.device
        h = self.token_embedding(x)
        q = self.q_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        k = self.k_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        v = self.v_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.d_head)
        mask = torch.triu(torch.ones((L, L), device=device), diagonal=1).bool()
        scores = scores.masked_fill(mask, float('-inf'))
        attn_probs = F.softmax(scores, dim=-1)
        self.last_attn = attn_probs.detach()
        context = torch.matmul(attn_probs, v)
        h = context.transpose(1, 2).contiguous().view(B, L, self.d_model)
        return self.output_head(h).squeeze(-1)


class HypothesisLucidTransformer(nn.Module):
    """LUCID Attention Transformer.

    Uses RMSNorm on keys and triangular solve on values to enable
    better gradient flow and escape from attention sinks.
    """

    def __init__(self, d_model=256, seq_len=10):
        super().__init__()
        self.d_model = d_model
        self.d_head = d_model
        self.token_embedding = nn.Embedding(10, d_model)
        self.q_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_proj = nn.Linear(d_model, d_model, bias=False)
        self.v_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_rms = nn.RMSNorm(self.d_head)
        self.output_head = nn.Linear(d_model, 1)

    def forward(self, x):
        B, L = x.shape
        device = x.device
        h = self.token_embedding(x)
        q = self.q_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        k = self.k_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        v = self.v_proj(h).view(B, L, 1, self.d_model).transpose(1, 2)
        k_rms = self.k_rms(k)
        kkt = torch.matmul(k_rms, k_rms.transpose(-2, -1)) / math.sqrt(self.d_head) - math.sqrt(self.d_head)
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.d_head)
        mask = torch.triu(torch.ones((L, L), device=device), diagonal=1).bool()
        kkt = kkt.masked_fill(mask, -float('inf'))
        scores = scores.masked_fill(mask, -float('inf'))
        kkt = torch.exp(kkt)
        v = torch.linalg.solve_triangular(kkt, v, upper=False, unitriangular=True)
        attn_probs = F.softmax(scores, dim=-1)
        context = torch.matmul(attn_probs, v)
        h = context.transpose(1, 2).contiguous().view(B, L, self.d_model)
        return self.output_head(h).squeeze(-1)


def main():
    # Configuration
    d_model = 256
    seq_len = 10
    vocab_size = 10
    batch_size = 64
    lr = 1e-3
    p1_steps = 30000
    p2_steps = 10000
    total_steps = p1_steps + p2_steps
    warmup_steps = int(0.05 * total_steps)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    print('=' * 60)
    print('LUCID vs Softmax Attention Sink Experiment')
    print('=' * 60)
    print(f'Configuration:')
    print(f'  d_model={d_model}, seq_len={seq_len}, vocab_size={vocab_size}')
    print(f'  batch_size={batch_size}, lr={lr}')
    print(f'  Cosine annealing with {warmup_steps} warmup steps (5%)')
    print(f'  Phase 1: {p1_steps} steps (identity)')
    print(f'  Phase 2: {p2_steps} steps (cumulative average)')
    print(f'  Device: {device}')
    print()

    results = {}

    for name, ModelClass in [('Softmax', HypothesisTransformer), ('LUCID', HypothesisLucidTransformer)]:
        print(f'=== Training {name} ===')

        # Set seed for reproducibility
        seed = 42
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

        model = ModelClass(d_model=d_model, seq_len=seq_len).to(device)
        model.apply(lambda m: init_weights(m, d_model))
        optimizer = optim.Adam(model.parameters(), lr=lr)
        scheduler = get_cosine_schedule_with_warmup(optimizer, warmup_steps, total_steps)

        p1_losses = []
        p2_losses = []

        # Phase 1: Identity task
        print('Phase 1 (Identity)...')
        for step in range(p1_steps):
            model.train()
            optimizer.zero_grad()
            inputs = generate_unique_batch(batch_size, seq_len=seq_len, vocab_size=vocab_size, device=device)
            targets = inputs.float()
            loss = F.mse_loss(model(inputs), targets)
            loss.backward()
            optimizer.step()
            scheduler.step()
            p1_losses.append(loss.item())
            if step % 10000 == 0 or step == p1_steps - 1:
                print(f'  Step {step+1}/{p1_steps} | Loss: {loss.item():.6f} | LR: {scheduler.get_last_lr()[0]:.6f}')

        # Check attention pattern after Phase 1 (for Softmax only)
        if name == 'Softmax':
            model.eval()
            with torch.no_grad():
                test_input = generate_unique_batch(1, seq_len=seq_len, vocab_size=vocab_size, device=device)
                _ = model(test_input)
                attn = model.last_attn.squeeze()
                diag = attn.diag().mean().item()
                offdiag_mask = torch.tril(torch.ones(seq_len, seq_len, device=device), diagonal=-1).bool()
                offdiag = attn[offdiag_mask].mean().item()
                print(f'  After Phase 1 - Attn diag: {diag:.4f}, offdiag: {offdiag:.6f}')

        # Phase 2: Cumulative Average task
        print('Phase 2 (Cumulative Average)...')
        for step in range(p2_steps):
            model.train()
            optimizer.zero_grad()
            inputs = generate_unique_batch(batch_size, seq_len=seq_len, vocab_size=vocab_size, device=device)
            targets = cumulative_average(inputs)
            loss = F.mse_loss(model(inputs), targets)
            loss.backward()
            optimizer.step()
            scheduler.step()
            p2_losses.append(loss.item())
            if step % 2000 == 0 or step == p2_steps - 1:
                print(f'  Step {step+1}/{p2_steps} | Loss: {loss.item():.6f} | LR: {scheduler.get_last_lr()[0]:.6f}')

        results[name] = {'p1_losses': p1_losses, 'p2_losses': p2_losses}
        print()

    # Save results
    np.savez('exp_d256_seq10_unique_cosine.npz',
             softmax_p1=np.array(results['Softmax']['p1_losses']),
             softmax_p2=np.array(results['Softmax']['p2_losses']),
             lucid_p1=np.array(results['LUCID']['p1_losses']),
             lucid_p2=np.array(results['LUCID']['p2_losses']))
    print('Saved: exp_d256_seq10_unique_cosine.npz')

    # Print summary
    print()
    print('=' * 60)
    print('RESULTS')
    print('=' * 60)

    softmax_p2_final = results['Softmax']['p2_losses'][-1]
    softmax_p2_min = min(results['Softmax']['p2_losses'])
    lucid_p2_final = results['LUCID']['p2_losses'][-1]
    lucid_p2_min = min(results['LUCID']['p2_losses'])
    baseline = 1.83  # Predicting the mean

    print(f'\nPhase 2 Final Loss:')
    print(f'  Softmax: {softmax_p2_final:.6f} (min: {softmax_p2_min:.6f})')
    print(f'  LUCID:   {lucid_p2_final:.6f} (min: {lucid_p2_min:.6f})')
    print(f'\nBaseline (predict mean): ~{baseline}')
    print(f'\nImprovement over baseline:')
    print(f'  Softmax: {100*(baseline - softmax_p2_final)/baseline:.1f}%')
    print(f'  LUCID:   {100*(baseline - lucid_p2_final)/baseline:.1f}%')


if __name__ == '__main__':
    main()
